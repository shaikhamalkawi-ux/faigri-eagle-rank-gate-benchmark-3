# GitHub release note

Public development repository authorized by the author team on 2026-09-08.

Repository: https://github.com/shaikhamalkawi-ux/faigri-eagle-rank-gate-benchmark-3

Run `bash run_all.sh` after checkout. The included GitHub Actions workflow runs the same test suite. An immutable Zenodo DOI release and explicit reuse licenses remain pending.
